package game;

//sets Jerry's x and y location that will be randomized later

public class Jerry{
	//Jerry's x coordinate
	float xJ;
	//Jerry's y coordinate
	float yJ;
	
	//constructor
	public Jerry(){
		//initialize x and y of Jerry
		xJ = 0;
		yJ = 0;
	}
	
	
}